/* Home page extras: calendar, film-leader countdown, viewfinder timecode */
(function () {
  'use strict';
  var $ = function (s) { return document.querySelector(s); };
  var reduce = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
  function pad(n) { return (n < 10 ? '0' : '') + n; }

  var g = $('#calG');
  if (g) {
    var tags = { 1: 'Reel', 3: 'Post', 4: 'Story', 6: 'Reel', 8: 'Post', 10: 'Ad', 11: 'Reel', 13: 'Story', 15: 'Post', 17: 'Reel', 18: 'Ad', 20: 'Story', 22: 'Post', 24: 'Reel', 25: 'Story', 27: 'Post' }, html = '';
    for (var d = 1; d <= 28; d++) { var t = tags[d]; html += '<div class="d">' + d + (t ? '<span class="tg ' + t.toLowerCase() + '" style="--i:' + d + '">' + t + '</span>' : '') + '</div>'; }
    g.innerHTML = html;
  }
  var cnt = $('#count'), seq = ['3', '2', '1'], ci = 0;
  if (cnt && !reduce) setInterval(function () { ci = (ci + 1) % seq.length; cnt.textContent = seq[ci]; }, 1000);
  var vf = $('#vfTc'), fr = 12 * 25;
  if (vf && !reduce) setInterval(function () {
    if (document.hidden) return;
    fr++; var s = Math.floor(fr / 25);
    vf.textContent = '00:' + pad(Math.floor(s / 60) % 60) + ':' + pad(s % 60) + ':' + pad(fr % 25);
  }, 40);
})();
